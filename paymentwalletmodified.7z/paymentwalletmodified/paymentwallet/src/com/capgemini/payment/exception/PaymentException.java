package com.capgemini.payment.exception;

public class PaymentException extends Exception {
	public PaymentException()
	{
		super();
	}
	
	public PaymentException(String msg)
	{
		super(msg);
	}
}
