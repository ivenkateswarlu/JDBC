package com.capgemini.payment.ui;

import java.util.List;
import java.util.Scanner;

import com.capgemini.payment.bean.CustomerBean;
import com.capgemini.payment.bean.TranscationBean;
import com.capgemini.payment.exception.PaymentException;
import com.capgemini.payment.exception.PaymentExceptionMessage;
import com.capgemini.payment.service.IService;
import com.capgemini.payment.service.ServiceImp;

public class Client 
{
	static IService service=new ServiceImp();
	static Scanner scan = new Scanner(System.in);
	public static void main(String[] args) throws PaymentException 
	{
		// TODO Auto-generated method stub
		System.out.println("Welcome to BankWallet");
		while (true) 
		{
			System.out.println("---------------------------------");
			System.out.println("1) Create Account");
			System.out.println("2) Deposit");
			System.out.println("3) WithDrawl");
			System.out.println("4) Fund Transfer");
			System.out.println("5) Show Balance");
			System.out.println("6) Print Transcations");
			System.out.println("7) Exit");
			System.out.println("-----------------------------------");
			System.out.println(" ");
			System.out.println("enter the choice");
			int choice=scan.nextInt();
			switch (choice) 
			{
				case 1:
					createAccount();
					break;
				case 2:
					deposit();
					break;
				case 3:
					withDrawl();
					break;
				case 4:
					fundTrasfer();
					break;
				case 5:
					showBalance();
					break;
				case 6:
					printTranscations();
					break;
				case 7:
					System.out.println("exited successfully");
					System.exit(0);
					break;
				default:
					System.out.println("entered wrong choice!!!!!!!!");
					break;
			}
		}
	}

	private static void printTranscations() throws PaymentException {
		// TODO Auto-generated method stub
		System.out.println("enter the phonenumber");
		String phoneNumber=scan.next();
		List<TranscationBean> transcationsdetails=null;
		transcationsdetails=service.printTranscations();
		if(transcationsdetails!=null)
		{
			for (TranscationBean transcationBean : transcationsdetails)
			{
				if(transcationBean.getNumber().equals(phoneNumber))
					System.out.println(transcationBean);
			}
		}
		else
			throw new PaymentException(PaymentExceptionMessage.ERROR14);
	}

	private static void showBalance() throws PaymentException {
		// TODO Auto-generated method stub
		System.out.println("enter the phoneNumber");
		String phoneNumber=scan.next();
		CustomerBean bean;
		bean=service.showBalance(phoneNumber);
		if(bean!=null)
			System.out.println("Current Balance "+bean.getCustomerBalance());
		else
			throw new PaymentException(PaymentExceptionMessage.ERROR14);
	}

	private static void fundTrasfer() throws PaymentException 
	{
		// TODO Auto-generated method stub
		System.out.println("enter the Source AccountNumber");
		String sourceNumber=scan.next();
		System.out.println("enter the Target AccountNumber");
		String targetNumber=scan.next();
		System.out.println("enter the amount");
		double amount=scan.nextDouble();
		boolean result=service.fundTransfer(sourceNumber, targetNumber, amount);
		if(result)
			System.out.println("FundTransfer Done");
		else
			throw new PaymentException(PaymentExceptionMessage.ERROR15);
	}

	private static void withDrawl() throws PaymentException {
		// TODO Auto-generated method stub
		boolean result=false;
		System.out.println("enter the phoneNumber");
		String phoneNumber=scan.next();
		System.out.println("enter the amount to withdraw");
		double amount=scan.nextDouble();
		result=service.withDraw(phoneNumber, amount);
		if(result)
			System.out.println("Withdraw successfully");
		else
			throw new PaymentException(PaymentExceptionMessage.ERROR11);
	}

	private static void deposit() throws PaymentException {
		// TODO Auto-generated method stub
		boolean result=false;
		System.out.println("enter the phoneNumber");
		String phoneNumber=scan.next();
		System.out.println("enter the amount to deposit");
		double amount=scan.nextDouble();
		result=service.deposit(phoneNumber, amount);
		if(result)
			System.out.println("deposited successfully");
		else
			throw new PaymentException(PaymentExceptionMessage.ERROR10);
	}

	private static void createAccount() throws PaymentException {
		// TODO Auto-generated method stub
		boolean result=false;
		System.out.println("enter the name");
		String name=scan.next();
		System.out.println("enter the age");
		int age=scan.nextInt();
		System.out.println("enter the phoneNumber");
		String number=scan.next();
		System.out.println("enter the balance");
		double balance=scan.nextDouble();
		CustomerBean bean=new CustomerBean();
		bean.setCustomerName(name);
		bean.setCustomerAge(age);
		bean.setAccountNumber(number);
		bean.setCustomerBalance(balance);
		bean.setTranscationBean(null);
		result=service.createAccount(bean);
		if(result)
			System.out.println("Created Successfully");
		else
			throw new PaymentException(PaymentExceptionMessage.ERROR9);
	}
}
