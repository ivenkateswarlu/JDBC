package com.capgemini.payment.service;

import java.util.List;

import com.capgemini.payment.bean.CustomerBean;
import com.capgemini.payment.bean.TranscationBean;
import com.capgemini.payment.exception.PaymentException;

public interface IService 
{
	public boolean validate(CustomerBean c) throws PaymentException;
	public boolean createAccount(CustomerBean c) throws PaymentException;
	public CustomerBean showBalance(String phoneNumber) throws PaymentException;
	public boolean deposit(String phoneNumber,double amount) throws PaymentException;
	public boolean withDraw(String phoneNumber,double amount) throws PaymentException;
	public boolean fundTransfer(String sourcePhoneNumber,String targetPhoneNumber,double amount) throws PaymentException;
	public List<TranscationBean> printTranscations();
}
