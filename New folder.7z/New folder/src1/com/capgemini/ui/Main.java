package com.capgemini.ui;

import java.sql.SQLException;
import java.util.Scanner;

import com.capgemini.db.CustomerDAO;
import com.capgemini.db.CustomerDAOImpl;

public class Main {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		
		CustomerDAO dao=new CustomerDAOImpl();
		// while(true){
		System.out.println("Customer Application");
		System.out.println("---------------------");
		System.out.println("1.Add New Customer");
		System.out.println("2.Update Customer");
		System.out.println("3.Display All Customer");
		System.out.println("4.Delete Customer");
		System.out.println("5.Exit");
		Scanner scanner = new Scanner(System.in);
		int choice = scanner.nextInt();
		switch (choice) {
		case 1:
			add();

			break;
		case 2:
			update();

			break;
		case 3:
			display();

			break;
		case 4:
			remove();

			break;
		case 5:
			System.out.println("Thank you");
			System.exit(0);

			break;

		default:
			System.out.println("Enter correct value");
			break;
		}
	}

	// }
	public static void add() {

	}

	public static void update() {

	}

	public static void display() throws ClassNotFoundException, SQLException {
		CustomerDAO dao=new CustomerDAOImpl();
		dao.getAllCustomers();
	}

	public static void remove() throws ClassNotFoundException, SQLException {
		CustomerDAO dao=new CustomerDAOImpl();
int inp_id=0;
Scanner scanner=new Scanner(System.in);
System.out.println("Enter Id to remove");
inp_id=scanner.nextInt();
boolean result=dao.removeCustomer(inp_id);
if(result==true){
	System.out.println("record deleted :-)");
}
else

	System.out.println("Not Deleted");
	


	}
}